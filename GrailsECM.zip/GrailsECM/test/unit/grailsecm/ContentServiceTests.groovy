package grailsecm

import grails.test.*
import org.apache.chemistry.opencmis.client.api.*
import org.apache.chemistry.opencmis.commons.data.*

class ContentServiceTests extends GrailsUnitTestCase {
    def service 
    
    protected void setUp() {
        super.setUp()
        mockConfig('')

        service = new ContentService()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testNodeContent() {
        def testStr = 'Test'
        // ensure InputStream gives desired result
        InputStream.metaClass.getText = { return testStr }
    
        def contentStreamControl = mockFor(ContentStream)
        contentStreamControl.demand.getStream(1..1) { -> return [text:testStr] as InputStream }

        def documentControl = mockFor(Document)
        documentControl.demand.getContentStream(1..1) { -> return contentStreamControl.createMock()} 

        def sessionControl = mockFor(Session)
        sessionControl.demand.getObject(1..1) { arg -> return documentControl.createMock()}
    
        def sessionFactoryControl = mockFor(SessionFactory)
        sessionFactoryControl.demand.createSession(1..1) { arg -> return sessionControl.createMock()}
        
        service.cmisSessionFactory = sessionFactoryControl.createMock()
        
        def text = service.getNodeContent('cafebabe')
        assertNotNull text
        assertEquals testStr, text
        
        // reset
        InputStream.metaClass = null
    }
}
