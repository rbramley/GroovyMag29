package grailsecm

import grails.test.*

class ContentTagLibTests extends TagLibUnitTestCase {
    def body
    
    protected void setUp() {
        super.setUp()
        mockConfig('')
        mockTagLib(ContentTagLib)
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testNodeContent() {
        def contentServiceControl = mockFor(ContentService) 
        contentServiceControl.demand.getNodeContent(1..1) { str -> return "<html>Test</html>" }
        tagLib.contentService = contentServiceControl.createMock()
        
        def out = new StringWriter()
        tagLib.metaClass.out = out
        tagLib.nodeContent(['nodeRef':"cafebabe"], null)
        assertTrue out.toString().contains('Test')
    }
}
