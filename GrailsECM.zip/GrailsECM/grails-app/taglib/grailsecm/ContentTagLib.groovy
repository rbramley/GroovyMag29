package grailsecm

class ContentTagLib {
    def contentService

    def nodeContent = { attrs, body ->
      if (attrs.nodeRef) {
        out << contentService.getNodeContent(attrs.nodeRef)
      }
    }
}
