// Place your Spring DSL code here
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl

beans = {
    cmisSessionFactory(SessionFactoryImpl) {}
}
