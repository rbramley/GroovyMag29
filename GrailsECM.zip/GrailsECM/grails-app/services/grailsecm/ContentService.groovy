package grailsecm

import org.codehaus.groovy.grails.commons.ConfigurationHolder as CH

import org.apache.chemistry.opencmis.client.api.* 
import org.apache.chemistry.opencmis.client.runtime.* 
import org.apache.chemistry.opencmis.commons.* 
import org.apache.chemistry.opencmis.commons.exceptions.* 
import org.apache.chemistry.opencmis.commons.enums.* 

class ContentService {
    static transactional = true
    
    def cmisSessionFactory

    def params = [ 
          (SessionParameter.USER):CH.config.cmis.user, 
          (SessionParameter.PASSWORD):CH.config.cmis.password, 
          (SessionParameter.ATOMPUB_URL):CH.config.cmis.url,
          (SessionParameter.BINDING_TYPE):BindingType.ATOMPUB.value(), 
          (SessionParameter.REPOSITORY_ID):CH.config.cmis.repository,
          (SessionParameter.LOCALE_ISO3166_COUNTRY):"gb", 
          (SessionParameter.LOCALE_ISO639_LANGUAGE):"en", 
          (SessionParameter.LOCALE_VARIANT):""] 

    def getNodeContent(nodeRef) {
        // create the session 
        def session = cmisSessionFactory.createSession(params)

        if(session) {
            // get the content
            def obj = session.getObject(new ObjectIdImpl(nodeRef))
            def is = obj?.getContentStream()?.getStream()
            return is?.getText()
        }
    }
}
